//
//  ProjectTests.h
//  ProjectTests
//
//  Created by Van't Zelfden, Justin on 10/13/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface ProjectTests : SenTestCase

@end
